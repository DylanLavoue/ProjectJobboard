import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { from, Observable, of } from 'rxjs';
import { User } from '../entities/user.entity';
import { LoginUserDto } from '../user/login-user-dto';

const bcrypt = require('bcrypt');
@Injectable()
export class AuthService {
  constructor(private readonly jwtService: JwtService) {}

  generateJWT(user: any): Observable<string> {
    return from(this.jwtService.signAsync(user, { expiresIn: '1h' }));
  }
  async hashPasswd(passwd: string) {
    return bcrypt.hashSync(passwd, 12);
  }
  comparePwd(newPwd: string, hashedPwd: string): Observable<any> {
    return of<any | boolean>(bcrypt.compare(newPwd, hashedPwd));
  }
}
