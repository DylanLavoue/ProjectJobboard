import { Module } from '@nestjs/common';
import { AuthService } from './auth.service';
import { JwtModule } from '@nestjs/jwt';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { configs } from '@typescript-eslint/eslint-plugin';

@Module({
  imports: [
    JwtModule.registerAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: async (ConfigService: ConfigService) => ({
        secret: 'urethndvkngkjdbgkdkdnbdmbmdbdf', //'ConfigService.get('JWT_SECRET')',
      }),
    }),
  ],
  exports: [AuthService],
  providers: [AuthService],
})
export class AuthModule {}
