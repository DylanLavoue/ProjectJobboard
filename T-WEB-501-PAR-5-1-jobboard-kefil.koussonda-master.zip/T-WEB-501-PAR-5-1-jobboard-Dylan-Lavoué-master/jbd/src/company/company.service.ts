import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Company } from '../entities/company.entity';
import { Repository } from 'typeorm';
import { CreateCompanyDto } from './dto/create-company-dto';

@Injectable()
export class CompanyService {
  constructor(
    @InjectRepository(Company)
    private readonly cpnRepository: Repository<Company>,
  ) {}

  async findOne(id: number) {
    const cpn = await this.cpnRepository.findOne(id);
    if (!cpn) {
      throw new HttpException(
        'Cette entreprise est introuvable',
        HttpStatus.NOT_FOUND,
      );
    }
    return cpn;
  }
  create(createCompanyDto: CreateCompanyDto) {
    const cpn = this.cpnRepository.create(createCompanyDto as any);
    return this.cpnRepository.save(cpn);
  }
}
