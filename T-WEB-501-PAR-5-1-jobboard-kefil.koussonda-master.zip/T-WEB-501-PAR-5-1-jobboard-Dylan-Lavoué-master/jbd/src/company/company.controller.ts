import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { CompanyService } from './company.service';
import { CreateCompanyDto } from './dto/create-company-dto';

@Controller('company')
export class CompanyController {
  constructor(private readonly cpnService: CompanyService) {}

  @Get(':id')
  findOne(@Param('id') id: number) {
    return this.cpnService.findOne(id);
  }
  @Post()
  create(@Body() cpnData: CreateCompanyDto) {
    return this.cpnService.create(cpnData);
  }
}
