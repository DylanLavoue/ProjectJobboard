import { Body, Controller, Post } from '@nestjs/common';
import { ApplicationService } from './application.service';
import { CreateAppliDto } from './create-appli-dto';

@Controller('application')
export class ApplicationController {
  constructor(private readonly appliService: ApplicationService) {}

  @Post()
  apply(@Body() appliData: CreateAppliDto) {
    return this.appliService.create(appliData);
  }
}
