import { IsNumber, IsOptional } from 'class-validator';

export class CreateAppliDto {
  @IsNumber()
  job: number;

  @IsNumber()
  user: number;
  @IsOptional()
  cover_?: string;
  @IsOptional()
  cv_?: string;
}
