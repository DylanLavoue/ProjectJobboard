import { Injectable } from '@nestjs/common';
import { Application } from '../entities/appli.entity';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { CreateAppliDto } from './create-appli-dto';

@Injectable()
export class ApplicationService {
  constructor(
    @InjectRepository(Application)
    private readonly aplRepository: Repository<Application>,
  ) {}

  async findByJob(job_id: number) {
    const apls = await this.aplRepository.find({
      where: { job: job_id },
    });
    return apls;
  }
  create(aplData: CreateAppliDto) {
    const apl = this.aplRepository.create(aplData as any);
    return this.aplRepository.save(apl);
  }
}
