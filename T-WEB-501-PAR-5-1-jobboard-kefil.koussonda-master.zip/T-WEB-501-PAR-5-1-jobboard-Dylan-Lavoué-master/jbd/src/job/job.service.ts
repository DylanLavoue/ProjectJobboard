import {
  HttpException,
  HttpStatus,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { Job } from '../entities/job.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UpdateJobDto } from './dto/update-job-dto';
import { CreateJobDto } from './dto/create-job-dto';
import { PaginationQueryDto } from '../common/dto/pagination-query.dto';
import { Jobmeta } from '../entities/Jobmeta.entity';
import { CreateJmDto } from './dto/create-jm-dto';

@Injectable()
export class JobService {
  constructor(
    @InjectRepository(Job)
    private readonly jobRepository: Repository<Job>,
    @InjectRepository(Jobmeta)
    private readonly jmRepository: Repository<Jobmeta>,
  ) {}
  findAll(paginationQuery: PaginationQueryDto) {
    const { limit, offset } = paginationQuery;
    return this.jobRepository.find({
      relations: ['author', 'category'],
      skip: offset,
      take: limit,
    });
  }
  async findOne(id: string) {
    const job = await this.jobRepository.findOne(id, {
      relations: ['author', 'category'],
    });
    if (!job) {
      throw new HttpException('Annonce introuvable', HttpStatus.NOT_FOUND);
    }
    return job;
  }

  createJm(jmData: CreateJmDto) {
    const jm = this.jmRepository.create(jmData as any);
    return this.jmRepository.save(jm);
  }
  async getJobMeta(id: number) {
    const jobm = await this.jmRepository.find({
      where: { job: +id },
    });
    if (!jobm) {
      throw new HttpException(
        'Les détails de cette annonce sont introuvables !',
        HttpStatus.NOT_FOUND,
      );
    }
    return jobm;
  }
  async getJobsByCategory(
    category_id: number /*,
    paginationQuery: PaginationQueryDto,*/,
  ) {
    // const { limit, offset } = paginationQuery;
    return this.jobRepository.find({
      // skip: offset,
      // take: limit,
      where: {
        category: +category_id,
      },
    });
  }
  create(createJobDto: CreateJobDto) {
    const job = this.jobRepository.create(createJobDto as any);
    return this.jobRepository.save(job);
  }

  async update(id: string, updateJobDto: UpdateJobDto) {
    const job = await this.jobRepository.preload({
      id: +id,
      ...updateJobDto,
    } as any);
    if (!job) {
      throw new NotFoundException('Cette annonce est introuvable !');
    }
    return this.jobRepository.save(job);
  }
  async remove(id: string) {
    const job = await this.jobRepository.findOne(id);
    return this.jobRepository.remove(job);
  }
}
