import { Module } from '@nestjs/common';
import { JobController } from './job.controller';
import { JobService } from './job.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Job } from '../entities/job.entity';
import { User } from '../entities/user.entity';
import { Category } from '../entities/category.entity';
import { Jobmeta } from '../entities/Jobmeta.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Job, User, Category, Jobmeta])],
  controllers: [JobController],
  providers: [JobService],
})
export class JobModule {}
