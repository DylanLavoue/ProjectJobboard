import { IsNumber, IsString } from 'class-validator';

export class CreateJobDto {
  @IsString()
  readonly title: string;

  @IsString()
  readonly shortDesc: string;

  @IsString()
  contract: string;

  @IsString()
  readonly salary: string;

  @IsString()
  readonly place: string;

  @IsString()
  readonly date: string;

  @IsString()
  readonly meta: string;

  readonly author: number;

  readonly application?: number[];

  readonly category: number[];
}
