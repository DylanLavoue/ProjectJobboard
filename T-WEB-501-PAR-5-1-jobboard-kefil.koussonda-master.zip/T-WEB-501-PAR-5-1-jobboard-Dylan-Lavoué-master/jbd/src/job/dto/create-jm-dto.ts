import { IsNumber, IsString } from 'class-validator';

export class CreateJmDto {
  @IsString()
  readonly desc: string;
  @IsString()
  readonly resp: string;
  @IsString()
  readonly study: string;
  @IsNumber()
  readonly job: number;
}
