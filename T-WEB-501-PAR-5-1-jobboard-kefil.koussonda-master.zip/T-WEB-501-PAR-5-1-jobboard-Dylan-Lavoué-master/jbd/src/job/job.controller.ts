import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
} from '@nestjs/common';
import { JobService } from './job.service';
import { CreateJobDto } from './dto/create-job-dto';
import { UpdateJobDto } from './dto/update-job-dto';
import { PaginationQueryDto } from '../common/dto/pagination-query.dto';
import path from 'path/posix';
import { CreateJmDto } from './dto/create-jm-dto';

@Controller('job')
export class JobController {
  constructor(private readonly jobService: JobService) {}
  @Get()
  findAll(@Query() paginationQuery: PaginationQueryDto) {
    // const { limit, offset } = paginationQuery;
    return this.jobService.findAll(paginationQuery);
  }

  @Get(':id')
  findOne(@Param('id') id: number) {
    return this.jobService.findOne('' + id);
  }

  @Get('meta/:id')
  getJobMeta(@Param('id') id: number) {
    return this.jobService.getJobMeta(id);
  }

  @Get('category/:id')
  getJobsByCategory(
    @Param('id')
    cat_id: number /*,
    @Query() paginationQuery: PaginationQueryDto,*/,
  ) {
    // return this.jobService.getJobsByCategory(cat_id, paginationQuery);
    console.log(cat_id);
    return this.jobService.getJobsByCategory(cat_id);
  }

  @Post('/meta')
  createJm(@Body() createJmDto: CreateJmDto) {
    return this.jobService.createJm(createJmDto);
  }

  @Post()
  create(@Body() createJobDto: CreateJobDto) {
    console.log(createJobDto instanceof CreateJobDto);
    return this.jobService.create(createJobDto);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateJobDto: UpdateJobDto) {
    return this.jobService.update(id, updateJobDto);
  }
  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.jobService.remove(id);
  }
}
