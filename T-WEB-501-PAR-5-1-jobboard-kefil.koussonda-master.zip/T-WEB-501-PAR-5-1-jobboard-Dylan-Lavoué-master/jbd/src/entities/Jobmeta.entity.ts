import {
  Column,
  Entity,
  JoinColumn,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Job } from './job.entity';
import { type } from 'os';

@Entity()
export class Jobmeta {
  @PrimaryGeneratedColumn()
  id: string;

  @Column()
  desc: string;

  @Column()
  resp: string;

  @Column()
  study: string;

  @OneToOne((type) => Job, (job) => job.meta)
  @JoinColumn()
  job: Job;
}
