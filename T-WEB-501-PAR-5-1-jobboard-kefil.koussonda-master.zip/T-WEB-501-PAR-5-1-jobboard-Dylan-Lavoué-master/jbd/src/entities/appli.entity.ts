import {
  Column,
  Entity,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { User } from './user.entity';
import { type } from 'os';
import { Job } from './job.entity';
import { IsOptional } from 'class-validator';

@Entity()
export class Application {
  @PrimaryGeneratedColumn()
  id: number;
  @ManyToOne((type) => Job, (job) => job.applications)
  job: Job;
  @ManyToOne((type) => User, (user) => user.applications)
  user: User;

  @Column()
  @IsOptional()
  cover_?: string;

  @Column()
  @IsOptional()
  cv_?: string;
}
