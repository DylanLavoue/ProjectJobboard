import {
  BeforeInsert,
  Column,
  Entity,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Job } from './job.entity';
import { Company } from './company.entity';
import { Application } from './appli.entity';
import { rules } from '@typescript-eslint/eslint-plugin';
import { IsString } from 'class-validator';

@Entity()
export class User {
  @PrimaryGeneratedColumn()
  id: string;

  @Column()
  name: string;

  @Column()
  surname: string;

  @Column()
  email: string;

  @Column()
  passwd: string;

  @Column()
  tel: string;

  @OneToMany((type) => Job, (job) => job.author)
  jobs?: Job[];

  @OneToMany((type) => Application, (application) => application.user)
  applications?: Application[];

  @ManyToOne((type) => Company, (company) => company.users, {
    cascade: true,
    eager: true,
  })
  company?: Company;

  @BeforeInsert()
  emailToLowerCase() {
    this.email = this.email.toLowerCase();
  }
}
