import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { User } from './user.entity';
@Entity()
export class Company {
  @PrimaryGeneratedColumn()
  id: string;

  @Column()
  name: string;

  @Column()
  tel: string;

  @Column()
  address: string;

  @Column()
  activity: string;

  @OneToMany((type) => User, (user) => user.company)
  users: User[];
}
