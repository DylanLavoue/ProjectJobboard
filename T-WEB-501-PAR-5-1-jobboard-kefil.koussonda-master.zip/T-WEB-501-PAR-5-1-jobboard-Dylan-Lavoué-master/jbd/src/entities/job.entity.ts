import {
  Column,
  Entity,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { type } from 'os';
import { User } from './user.entity';
import { Category } from './category.entity';
import { Jobmeta } from './Jobmeta.entity';
import { Application } from './appli.entity';

@Entity()
export class Job {
  @PrimaryGeneratedColumn()
  id: string;

  @Column()
  title: string;

  @Column()
  shortDesc: string;

  @Column()
  contract: string;

  @Column()
  salary: string;

  @Column()
  place: string;

  @Column()
  date: string;

  @OneToOne((type) => Jobmeta, (jobmeta) => jobmeta.job, {
    cascade: true,
  })
  meta: Jobmeta;

  @ManyToOne((type) => User, (user) => user.jobs, {
    cascade: true,
    eager: true,
  })
  author: User;

  @OneToMany((type) => Application, (apl) => apl.job, {
    cascade: true,
  })
  applications?: Application[];

  @ManyToOne((type) => Category, (category) => category.jobs, {
    cascade: true,
    eager: true,
  })
  category: Category;
}
