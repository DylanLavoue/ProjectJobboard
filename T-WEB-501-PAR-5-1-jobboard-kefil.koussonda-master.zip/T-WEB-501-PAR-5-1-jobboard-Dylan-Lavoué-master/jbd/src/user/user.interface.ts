export interface UserInterface {
  name: string;
  surname: string;
  email: string;
  passwd: string;
  tel: string;
  jobs: string;
  job: string;
  company: string;
}
