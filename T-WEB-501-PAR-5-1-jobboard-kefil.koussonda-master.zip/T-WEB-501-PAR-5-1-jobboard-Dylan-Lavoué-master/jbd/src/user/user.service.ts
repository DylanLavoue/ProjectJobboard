import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { User } from '../entities/user.entity';
import { UserInterface } from './user.interface';
import { Repository } from 'typeorm';
import { CreateUserDto } from './create-user-dto';
import { AuthService } from '../auth/auth.service';
import { from, map, Observable, switchMap } from 'rxjs';
import { LoginUserDto } from './login-user-dto';
import { classToPlain } from 'class-transformer';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(User) private readonly userRepository: Repository<User>,
    private authService: AuthService,
  ) {}

  findAll(email: string) {
    return this.userRepository.findOne(email);
  }

  findOne(id: number) {
    const user = this.userRepository.findOne(id, {
      relations: ['jobs', 'job', 'company'],
    });
    if (!user) {
      throw new HttpException('Utilisateur introuvable', HttpStatus.NOT_FOUND);
    }
  }

  create(userData: CreateUserDto) {
    this.authService.hashPasswd(userData.passwd).then((pwdHash) => {
      userData.passwd = pwdHash;
      const user = this.userRepository.create(userData as any);
      return this.userRepository.save(user as any);
    });
  }
  login(user: LoginUserDto): Observable<string> {
    console.log(user);
    return this.validateUser(user.email, user.passwd).pipe(
      switchMap((user: any) => {
        if (user) {
          return this.authService
            .generateJWT(classToPlain(user))
            .pipe(map((jwt: string) => jwt));
        } else return 'Email et/ou mot de passe incorrect(s)';
      }),
    );
  }
  validateUser(email: string, passwd: string): Observable<any> {
    return this.findByMail(email).pipe(
      switchMap((user: User) =>
        this.authService.comparePwd(passwd, user.passwd).pipe(
          map((match: boolean) => {
            if (match) {
              const { passwd, ...result } = user;
              // console.log(user);
              return user;
            } else throw Error;
          }),
        ),
      ),
    );
  }
  findByMail(email: string): Observable<User> {
    return from(
      this.userRepository.findOne({ email }, { relations: ['company'] }),
    );
  }
}
