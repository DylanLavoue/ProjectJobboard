import {
  Body,
  Controller,
  Param,
  Post,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { UserService } from './user.service';
import { CreateUserDto } from './create-user-dto';
import { LoginUserDto } from './login-user-dto';
import { map, Observable } from 'rxjs';
import { User } from '../entities/user.entity';
import { FileInterceptor } from '@nestjs/platform-express';

@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Post()
  create(@Body() createUserDto: CreateUserDto) {
    return this.userService.create(createUserDto);
  }

  @Post('/login')
  login(@Body() user: LoginUserDto): Observable<any> {
    return this.userService.login(user).pipe(
      map((jwt: string) => {
        return { access_token: jwt };
      }),
    );
  }
  @Post('upload')
  @UseInterceptors(FileInterceptor('cv', { dest: './public/cvs/' }))
  uploadFile(@UploadedFile() file: Express.Multer.File, type: string) {
    return file;
    // if (file) return true;
    // return false;
  }
}
