import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule} from "@angular/common/http";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { JobsComponent } from './jobs/jobs.component';
import {CommonModule} from "@angular/common";
import { JobmetaComponent } from './jobmeta/jobmeta.component';
import {LoginModule} from "./login/login.module";
import {SearchComponent} from "./search/search.component";
import { ApplicationComponent } from './jobs/application/application.component';
import { ProfileComponent } from './profile/profile.component';
import {SigninModule} from "./signin/signin.module";
import { AddjobComponent } from './jobs/addjob/addjob.component';


@NgModule({
  declarations: [
    AppComponent,
    JobsComponent,
    JobmetaComponent,
    SearchComponent,
    ApplicationComponent,
    ProfileComponent,
    AddjobComponent
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule,
    LoginModule,
    SigninModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
