export class Application{
  job: number;
  user: number;
  cover_: string;
  cv_: string;
}
