export class User{
  id: string;
  name: string;
  surname: string;
  email: string;
  passwd: string;
  tel: string;
  jobs: string;
  applications: string;
  company: string;
  iat: string;
  exp: number
}
