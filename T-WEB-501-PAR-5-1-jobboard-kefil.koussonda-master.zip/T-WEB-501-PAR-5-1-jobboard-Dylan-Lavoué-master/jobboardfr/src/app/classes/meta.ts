export class Meta{
  desc: string;
  resp: string;
  study: string;
  job: number;
}
