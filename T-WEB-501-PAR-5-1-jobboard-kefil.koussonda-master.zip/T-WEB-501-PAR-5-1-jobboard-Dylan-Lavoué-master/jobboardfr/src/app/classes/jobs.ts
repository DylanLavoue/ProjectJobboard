export class Jobs{
  id: string
  title: string;
  desc: string;
  salary: string;
  place: string;
  date: string;
  author: string;
  category: string;
}

