import { Injectable } from '@angular/core';
import {Observable} from "rxjs";
import {Router} from "@angular/router";
import {map} from "rxjs/operators";

@Injectable({
  providedIn: 'root'
})
export class SearchService {

  constructor(private readonly router: Router) { }

  getCurrentroute(): Observable<any>{
    return this.router.events.pipe(map((event) => {
      console.log(event);
    }))
  }
}
