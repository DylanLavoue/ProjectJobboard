import { Component, OnInit } from '@angular/core';
import {SearchService} from "./search.service";
import {NavigationStart, Router} from "@angular/router";

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
showSearchBar: boolean
  constructor(private searchService: SearchService, private route: Router) {
    this.route.events.subscribe((event: any)=>{
      if(event instanceof NavigationStart){
        if(route.url === 'login')
          this.showSearchBar = false
      }
    })
  }

  ngOnInit(): void {

  }

}
