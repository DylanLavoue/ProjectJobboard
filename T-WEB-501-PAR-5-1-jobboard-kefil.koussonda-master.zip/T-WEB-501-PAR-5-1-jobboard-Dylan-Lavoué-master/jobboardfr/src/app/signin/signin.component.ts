import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";
import {LoginService} from "../login/login.service";
import {Router} from "@angular/router";
import {JobsService} from "../jobs/jobs.service";
import {User} from "../classes/user";

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  // loginForm : any
  signinForm : FormGroup
  constructor( private loginService : LoginService, private formBuilder: FormBuilder, private readonly router: Router,
               private readonly jobService: JobsService) { }

  ngOnInit(): void {
    this.signinForm = new FormGroup({
      name: new FormControl(null, [Validators.required]),
      surname: new FormControl(null, [Validators.required]),
      email: new FormControl(null, [Validators.required, Validators.email, Validators.minLength(6)]),
      phone: new FormControl(null, [Validators.required]),
      passwd: new FormControl(null, [Validators.required, Validators.minLength(3)]),
      cpasswd: new FormControl(null, [Validators.required, Validators.minLength(3)])
    })
  }

  register(){
    let usr= {
      name: this.signinForm.value.name,
      surname: this.signinForm.value.surname ,
      email: this.signinForm.value.email,
      tel: this.signinForm.value.phone,
      passwd: this.signinForm.value.passwd
    }
    this.loginService.register(usr).subscribe((user)  => {
      if(user){
        this.loginService.seConnecter(usr.email, usr.passwd).subscribe(

        )

      }
    })

  }

}
