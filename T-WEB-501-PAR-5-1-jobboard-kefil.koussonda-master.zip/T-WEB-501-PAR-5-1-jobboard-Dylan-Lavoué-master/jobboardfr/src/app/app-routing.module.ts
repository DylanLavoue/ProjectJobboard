import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {JobsComponent} from "./jobs/jobs.component";
import {JobmetaComponent} from "./jobmeta/jobmeta.component";
import {LoginComponent} from "./login/login.component";
import {SigninComponent} from "./signin/signin.component";
import {ApplicationComponent} from "./jobs/application/application.component";
import {ProfileComponent} from "./profile/profile.component";
import {AddjobComponent} from "./jobs/addjob/addjob.component";

const routes: Routes = [
  {path: '', redirectTo: '/jobs', pathMatch:'full'},
  {path: 'jobs', component: JobsComponent, data: { num: 0}},
  {path: 'meta', component: JobmetaComponent, data: { num: 0}},
  {path: 'login', component: LoginComponent, data: { num: 0}},
  {path: 'signin', component: SigninComponent, data: { num: 0}},
  {path: 'apply', component: ApplicationComponent, data: { num: 0}},
  {path: 'profile', component: ProfileComponent, data: { num: 0}},
  {path: 'add', component: AddjobComponent, data: { num: 0}},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
