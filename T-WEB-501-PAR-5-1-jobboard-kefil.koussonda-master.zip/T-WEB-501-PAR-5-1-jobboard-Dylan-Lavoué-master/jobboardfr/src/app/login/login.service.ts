import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {map} from "rxjs/operators";
import {Observable} from "rxjs";
import jwt_decode from 'jwt-decode'
import {User} from "../classes/user";
import jwtDecode from "jwt-decode";
export const  JWT_NAME= "joabbord";
export class token{
  id: string;
  name: string;
  surname: string;
  email:string;
  passwd: string;
  tel: string;
  company: string;
  iat: number;
  exp: number
}

@Injectable({
  providedIn: 'root'
})


export class LoginService {
  currentUser : any;
  API_SERVER = "http://localhost:3000";

  constructor(private httpClient: HttpClient) { }

  public seConnecter(email: string, passwd: string): Observable<any>{
    // console.log(email)
    return this.httpClient.post<any>("http://localhost:3000/user/login", {email: email, passwd: passwd})
      .pipe(
      map((token) => {
        localStorage.setItem(JWT_NAME, token.access_token);

        return token;
      })
    )
  }

  public isExpired(){
    const token = localStorage.getItem('joabbord');

    if (token != null) {
      return true
    }
    else
    return false;
  }

  public getCurrentUser() {
    let token = localStorage.getItem(JWT_NAME);
    if (token) {
      this.currentUser = jwtDecode<User>(token);
      return this.currentUser
    }
  }

  public register(obj: any){
    console.log(obj)
    return this.httpClient.post(`${this.API_SERVER}/user`, obj)
  }

}
