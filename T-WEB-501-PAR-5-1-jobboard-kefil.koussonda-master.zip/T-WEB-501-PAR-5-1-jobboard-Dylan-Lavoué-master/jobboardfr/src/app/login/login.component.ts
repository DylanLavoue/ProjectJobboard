import { Component, OnInit } from '@angular/core';
import {LoginService} from "./login.service";

import {map} from "rxjs/operators";
import {FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";
import jwtDecode from "jwt-decode";
import {Router} from "@angular/router";
import {JobsService} from "../jobs/jobs.service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  // loginForm : any
  loginForm : FormGroup


  constructor( private loginService : LoginService, private formBuilder: FormBuilder, private readonly router: Router, private readonly jobService: JobsService) { }

  ngOnInit(): void {
    this.loginForm = new FormGroup({
      email: new FormControl(null, [Validators.required, Validators.email, Validators.minLength(6)]),
      passwd: new FormControl(null, [Validators.required, Validators.minLength(3)])
    })
  }

  seConnecter () {

    this.loginService.seConnecter(this.loginForm.value.email,this.loginForm.value.passwd).pipe(
      map(token => {
            if(!token)
              console.log("Mot de passe incorrect !")
            else
              this.router.navigate(['/apply'])

      })
    ).subscribe()
  }

  goToSignIn(){
    this.router.navigate(['signin'])
  }


}
