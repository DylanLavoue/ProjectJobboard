import { Component, OnInit } from '@angular/core';
import {JobsService} from "../jobs.service";
import {ActivatedRoute, Router} from "@angular/router";
import {LoginService} from "../../login/login.service";
import {Application} from "../../classes/application";
import {User} from "../../classes/user";

@Component({
  selector: 'app-application',
  templateUrl: './application.component.html',
  styleUrls: ['./application.component.css']
})
export class ApplicationComponent implements OnInit {
  job_id: any;
  currentJob: any;
  jobByCategory: any
  selectedFile: any
  currentUser: User
  cvLink: string
  uf: any
  coverLink: string
  constructor(private readonly loginService: LoginService,
              private readonly jobService: JobsService,
              private readonly route: ActivatedRoute,
              private readonly router: Router) { }

  ngOnInit(): void {
    this.job_id = localStorage.getItem('job_id')
    if(this.job_id)
      this.jobService.getCurrentJob(this.job_id).subscribe(job => {
        this.currentJob = job;
        this.jobService.getJobByCategory(this.currentJob.category.id).subscribe(jobs =>{
          this.jobByCategory = jobs;
          console.log(this.jobByCategory)
        })
      })

  }

  uploadFile($event: any, type: string){

    this.selectedFile = $event.target.files[0];
    if(this.selectedFile){
      let sub = this.jobService.uploadFile(this.selectedFile).subscribe((file : any) =>{
        this.uf = file;
        if(type === 'cv')
          this.cvLink = this.uf.filename
        else if(type === 'cover')
          this.coverLink = this.uf.filename
      })

    }



  }

  apply(){
    this.currentUser = this.loginService.getCurrentUser()
    let appliData = {
      job: this.job_id,
      user: this.currentUser.id,
      cover_ : this.coverLink,
      cv_: this.cvLink
    }

    console.log(appliData)
    this.jobService.apply(<any>appliData).subscribe(result =>{
      if(result)
        this.router.navigate(['profile'])
    })
  }

}
