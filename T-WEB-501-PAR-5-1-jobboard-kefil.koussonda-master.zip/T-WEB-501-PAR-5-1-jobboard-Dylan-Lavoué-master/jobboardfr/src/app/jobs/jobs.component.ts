import { Component, OnInit } from '@angular/core';
import {JobsService} from "./jobs.service";
import {Router} from "@angular/router";
import {Jobs} from "../classes/jobs";
import {AppService} from "../app.service";
import {LoginService} from "../login/login.service";

@Component({
  selector: 'app-jobs',
  templateUrl: './jobs.component.html',
  styleUrls: ['./jobs.component.css']
})
export class JobsComponent implements OnInit {
  jobs: any;

  constructor(private jobService: JobsService, private router: Router, private appService: AppService, private readonly ls: LoginService) { }

  ngOnInit(): void {
    this.jobs = this.jobService.findAll().subscribe(jobs =>{
      this.jobs = jobs;
    });
    this.appService.setCurrentRoute(this.router.url)
  }

  goToReadMore(job: Jobs){
    localStorage.setItem("job_id", job.id.toString())
    this.router.navigate(['meta']).then(success => {
      console.log("success");
    })
  }

}
