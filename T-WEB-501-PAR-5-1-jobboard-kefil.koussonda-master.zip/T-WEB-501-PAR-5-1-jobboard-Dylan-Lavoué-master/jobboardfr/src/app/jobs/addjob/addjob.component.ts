import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {LoginService} from "../../login/login.service";
import {JobsService} from "../jobs.service";

@Component({
  selector: 'app-addjob',
  templateUrl: './addjob.component.html',
  styleUrls: ['./addjob.component.css']
})
export class AddjobComponent implements OnInit {

  jobForm: FormGroup
  constructor(private readonly loginService: LoginService, private readonly jobService: JobsService) { }

  ngOnInit(): void {
    this.jobForm = new FormGroup({
      title: new FormControl(null, [Validators.required]),
      shortDesc: new FormControl(null, [Validators.required]),
      contract: new FormControl(null, [Validators.required,]),
      salary: new FormControl(null, [Validators.required]),
      place: new FormControl(null, [Validators.required]),
      category: new FormControl(null, [Validators.required])
    })
  }

  addjob(){
    let job = {
      title: this.jobForm.value.title,
      shortDesc: this.jobForm.value.shortDesc,
      contract: this.jobForm.value.contract,
      salary: this.jobForm.value.salary,
      place: this.jobForm.value.place,
      category: this.jobForm.value.category,
      date: new Date(),
      user: this.loginService.getCurrentUser().id
    }


    return this.jobService.addjob(job).subscribe(job =>{
      console.log(job)
    })

  }

}
