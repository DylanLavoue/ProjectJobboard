import { Injectable } from '@angular/core';
import { HttpClient} from "@angular/common/http";
import { Jobs } from "../classes/jobs";
import {Meta} from "../classes/meta";
import {Application} from "../classes/application";

@Injectable({
  providedIn: 'root'
})
export class JobsService {

  currentJob: any;
  job_id: number;
  API_SERVER = "http://localhost:3000";
  constructor(private httpClient: HttpClient) { }
  public findAll(){
    return this.httpClient.get<Jobs[]>(`${this.API_SERVER}/job?limit=3`)
  }

  public readMore(id: number){
    return this.httpClient.get<Meta>(`${this.API_SERVER}/job/meta/${id}`)
  }

  public getJobByCategory(category_id: any){
    return this.httpClient.get<Jobs[]>(`${this.API_SERVER}/job/category/${category_id}`)
  }
  public getCurrentJob(id: number){
    return this.httpClient.get<Jobs>(`${this.API_SERVER}/job/${id}`)
  }
  public uploadFile(file: any){
    let formData: any = new FormData();
    formData.append('cv', file);
    return this.httpClient.post(`${this.API_SERVER}/user/upload`,formData)
  }
  public apply(appliData: Application){
    return this.httpClient.post<Application>(`${this.API_SERVER}/application`, appliData)
  }

  public addjob(job: any){
    return this.httpClient.post<Jobs>(`${this.API_SERVER}/job`, job)
  }

}
