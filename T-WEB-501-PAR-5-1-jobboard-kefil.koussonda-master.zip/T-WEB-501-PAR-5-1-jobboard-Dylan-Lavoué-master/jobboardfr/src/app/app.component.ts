import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, NavigationStart, Router} from "@angular/router";
import {AppService} from "./app.service";
import {map} from "rxjs/operators";
import {SearchService} from "./search/search.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'jobboardfr';
  showSearchBar: boolean; showNav: boolean ;
  constructor( private appService: AppService, private route: Router, private route2: ActivatedRoute, private search: SearchService) {
      this.search.getCurrentroute().subscribe(r=>{
        if(this.route.url === '/login' || this.route.url === '/signin'|| this.route.url === '/add'){
          this.showSearchBar = false
          this.showNav = false
        }
        else if(this.route.url === '/profile'){
          this.showNav = true
          this.showSearchBar = false
        }
        else{
          this.showSearchBar = true
          this.showNav = true
        }
      })
  }
  ngOnInit(): void {

  }
}
