import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from "@angular/router";
import {JobsService} from "../jobs/jobs.service";
import {Jobs} from "../classes/jobs";
import jwtDecode  from "jwt-decode";
import {LoginService} from "../login/login.service";

@Component({
  selector: 'app-jobmeta',
  templateUrl: './jobmeta.component.html',
  styleUrls: ['./jobmeta.component.css']
})
export class JobmetaComponent implements OnInit {

  job_id : any;
  currentJob: any;
  jobByCategory: any;

  constructor( private route: ActivatedRoute, private jobService: JobsService, private readonly router : Router, private readonly loginService: LoginService) { }

  ngOnInit(): void {
    this.job_id = localStorage.getItem("job_id")

    if(this.job_id)
      this.jobService.getCurrentJob(this.job_id).subscribe(job => {
        this.currentJob = job;
        this.jobService.getJobByCategory(this.currentJob.category.id).subscribe(jobs =>{
          this.jobByCategory = jobs;
          console.log(this.jobByCategory)
        })
      })

  }

  setCurrentJob(job: Jobs){
    this.currentJob = job;
    localStorage.setItem('job_id', job.id.toString())
  }
  goToApply(){
    if(this.loginService.isExpired())
      this.router.navigate(['/apply'])
    else{
      this.router.navigate(['/login'])
    }

  }


}
