import { Injectable } from '@angular/core';
import {Router} from "@angular/router";

@Injectable({
  providedIn: 'root'
})
export class AppService {

  currentRoute = "";
  constructor(private router: Router) { }

  public getCurrentRoute(){
    return this.currentRoute;
  }
  public setCurrentRoute(route: string){
    this.currentRoute = route;
  }
}
